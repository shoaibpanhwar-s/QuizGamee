//
//  EquationsViewController.swift
//  QuizGame
//
//  Created by spkamran on 20/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit
import SafariServices

class EquationsViewController: UIViewController {

    @IBOutlet var Buttons: [UIButton]!
    override func viewDidLoad() {
        super.viewDidLoad()
 
    
    
    
    }

    
    
    
    
    
   
    
    
    @IBAction func Facebook(_ sender: Any) {
        
        
        guard let url = URL(string: "https://www.facebook.com/profile.php?id=100000533124837")
    
                else { return }
                let safariViewController = SFSafariViewController(url: url)
        
                self.present(safariViewController, animated: true, completion: nil)
    

        
        
    }
    
    @IBAction func Whatsapp(_ sender: Any) {
        
        
        let alrt = UIAlertController(title: "Welcome", message: "this is Whatsapp Number", preferredStyle: .alert)
        
        
        alrt.addTextField{(UITextField) in
            UITextField.text = "+923133393505"
        }
  
        alrt.addAction(UIAlertAction(title:"Cancel", style: .cancel))
        
        
        present(alrt, animated: true, completion: nil)
        

        
        
        
    }
    
    @IBAction func Gmail(_ sender: Any) {
        
        
        
        let alrt = UIAlertController(title: "Welcome", message: "this is GmailId", preferredStyle: .alert)
        
        alrt.addTextField{(UITextField) in
            UITextField.text = "Shoaib.panhwar205@gmail.com"
        }
        
        
        alrt.addAction(UIAlertAction(title:"Cancel", style: .cancel))
        
        
        present(alrt, animated: true, completion: nil)
        
        

    }
    
    @IBAction func skyp(_ sender: Any) {
        
        let alrt = UIAlertController(title: "Welcome", message: "this is GmailId", preferredStyle: .alert)
        
        alrt.addTextField{(UITextField) in
            UITextField.text = "Skyp Name:  shoaib.panhwar5"
        }
        
        
        alrt.addAction(UIAlertAction(title:"Cancel", style: .cancel))
        
        
        present(alrt, animated: true, completion: nil)
        
  
    }
    
    
    
    @IBAction func HomeButtonn(_ sender: Any) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "mainStory")
        
        present(pass!, animated: true, completion: nil)
        

    }
    
    
    
}

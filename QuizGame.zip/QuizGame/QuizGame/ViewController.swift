//
//  ViewController.swift
//  QuizGame
//
//  Created by spkamran on 16/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    
    
    let NameArray = ["MathQuiz","PictureQuiz","About Us"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return NameArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        
        cell.Namelbl?.text = NameArray[indexPath.row]
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            print("welcome in math")
            let pass = self.storyboard?.instantiateViewController(withIdentifier: "MathStory")
            
            present(pass!, animated: true, completion: nil)
            
            break
            
        case 1:
             let pass = self.storyboard?.instantiateViewController(withIdentifier: "ImageQuizStory")
            
            present(pass!, animated: true, completion: nil)
            
            break
            
        case 2:
            
            
            let pass = self.storyboard?.instantiateViewController(withIdentifier: "AboutStory")
            
            present(pass!, animated: true, completion: nil)
            
            
            break
            
            
        default:
           
            break
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    

}


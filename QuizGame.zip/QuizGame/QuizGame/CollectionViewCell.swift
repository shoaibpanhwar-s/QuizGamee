//
//  CollectionViewCell.swift
//  QuizGame
//
//  Created by spkamran on 16/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var MenuImg: UIImageView!
    
    
    @IBOutlet weak var Namelbl: UILabel!
}

//
//  PictureQuizViewController.swift
//  QuizGame
//
//  Created by spkamran on 17/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class PictureQuizViewController: UIViewController {
    
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var LevelLabel: UILabel!

    @IBOutlet weak var ScoreLabel: UILabel!
    
    @IBOutlet weak var Imagee: UIImageView!
    
    
    @IBOutlet weak var Button1: UIButton!
    
    
    @IBOutlet weak var Button2: UIButton!
    
    @IBOutlet weak var Button3: UIButton!
    
    
    
    @IBOutlet weak var Button4: UIButton!
    
    @IBOutlet weak var RightLabel: UILabel!
    
    @IBOutlet weak var WrongLabel: UILabel!
    
    
    
    var score:Int = Int();          // score variable
    
    var RightAttempt:Int = Int();        // attempt variable in Right label
    
    var wrongAttempt:Int = Int();   // attempt variable in Right label
    
    var timer = Timer() /// Timer variable
    
    var timee:Int = 90; // time variable
    
    var AudioPlyer:AVAudioPlayer = AVAudioPlayer();
    
    var AudioPlyer2:AVAudioPlayer = AVAudioPlayer();
    
    
    
    
    
    
    
    var imageArray = [#imageLiteral(resourceName: "home-icon"),#imageLiteral(resourceName: "snake"),#imageLiteral(resourceName: "lemon"),#imageLiteral(resourceName: "dog"),#imageLiteral(resourceName: "bananas"),#imageLiteral(resourceName: "strawberry"),#imageLiteral(resourceName: "aple"),#imageLiteral(resourceName: "tiger_PNG23222"),#imageLiteral(resourceName: "elephant"),#imageLiteral(resourceName: "mango"),#imageLiteral(resourceName: "pretty-cats-png-3"),#imageLiteral(resourceName: "Banana"),#imageLiteral(resourceName: "tree"),#imageLiteral(resourceName: "grass"),#imageLiteral(resourceName: "Streett"),#imageLiteral(resourceName: "ground-1"),#imageLiteral(resourceName: "hospital-png-hd-images-the-impact-that-visiting-hospitals-can-have-on-autistic-people-1200"),#imageLiteral(resourceName: "School"),#imageLiteral(resourceName: "Mouse"),#imageLiteral(resourceName: "Parrot"),#imageLiteral(resourceName: "Tomato")]
    
    var namearray = ["House","snake","Lemon","Dog","Bananas","Strawberry","Apple","Tiger","Elephant","Mango","Cat","Banana","Tree","Grass","Street","Ground","Hospital","School","Mouse","Parrot","Tomato"]
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        TimerStoreIntimeLabel()
        playAudio()
        playAudio2()
        
    }

    
    
    
    func playAudio(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "yay", ofType: ".wav")
            try
                AudioPlyer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    
    func playAudio2(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "ooooh", ofType: ".wav")
            try
                AudioPlyer2 = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    

    
    
    
    
    
    
    
    public func TimerStoreIntimeLabel(){ ///   =============>>>>>>TimerStoreIntimeLabel start
        
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(AlphabateQuizViewController.Action), userInfo: nil, repeats: true)
        
        
    }// ///  =======>>>>>> TimerStoreIntimeLabel start
    
    
    @objc func Action(){// ==============>>>>>>>> action of time
        
        timee -= 1
        
        timeLabel.text! = String("Time: 00:\(timee)")
        
        if timee == 0 {// =======>>>>>>>if
            
            timer.invalidate()
            
            let ttext = RightLabel.text!
            
            let ttext2 = WrongLabel.text!
            
            
            
            let alrt = UIAlertController(title: "Warning", message: "Time Out You Loss", preferredStyle: .alert)
            
            alrt.addAction(UIAlertAction(title: "\(ttext2)", style: .default))
            
            alrt.addAction(UIAlertAction(title:"\(ttext)", style: .default))
            
            alrt.addAction(UIAlertAction(title:"Cancel", style: .cancel))
            
            
            present(alrt, animated: true, completion: nil)
            
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
        }//====>>>>>>>if
        
        

    }//  ==============>>>>>>>> action of time
 
    
    
    
    
    @IBAction func Homebutton(_ sender: UIButton) {
        
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "MathStory")
        
        present(pass!, animated: true, completion: nil)
        
        
    }
    
    
    
    
    
    
    
    
    
    
    func StoreImageAndName (){
    
    
        let randomGenrate = Int(arc4random_uniform((UInt32(namearray.count))))
        
        LevelLabel.text! = namearray[randomGenrate]
        
        
        let imgnumb:Int = Int(arc4random_uniform(13))
        Imagee.image = imageArray[imgnumb]
        
    
        switch LevelLabel.text! {
            
        case "House":
            
            Imagee.image = imageArray[0]
            
            Button1.setTitle("\(namearray[0])", for: .normal)
            
           
            break
            
            
            
        case "snake" :
            
            Imagee.image = imageArray[1]
            Button2.setTitle("\(namearray[1])", for: .normal)
            
            break
            
            
        case "Lemon":
            
            Imagee.image = imageArray[2]
            Button3.setTitle("\(namearray[2])", for: .normal)
            
            break
            
            
            
        case "Dog" :
            
            Imagee.image = imageArray[3]
            Button4.setTitle("\(namearray[3])", for: .normal)
            
            
            break
            
            
        case "Bananas":
            Imagee.image = imageArray[4]
            Button1.setTitle("\(namearray[4])", for: .normal)
            
            break
            
            
            
        case "Strawberry" :
            
            Imagee.image = imageArray[5]
            
            Button2.setTitle("\(namearray[5])", for: .normal)
            
            break
            
            
        case "Apple":
            
            
            Imagee.image = imageArray[6]
            Button3.setTitle("\(namearray[6])", for: .normal)
            
            break
            
            
            
        case "Tiger" :
            
            
            Imagee.image = imageArray[7]
            Button4.setTitle("\(namearray[7])", for: .normal)
            
            break
            
            
        case "Elephant":
            
            
            Imagee.image = imageArray[8]
            Button1.setTitle("\(namearray[8])", for: .normal)
            
            break
            
            
            
        case "Mango" :
            
            
            Imagee.image = imageArray[9]
            Button2.setTitle("\(namearray[9])", for: .normal)
            
            break
            
            
        case "Cat":
            
            Imagee.image = imageArray[10]
            Button3.setTitle("\(namearray[10])", for: .normal)
            
            break
            
            
            
        case "Banana" :
            
            Imagee.image = imageArray[11]
            
            Button4.setTitle("\(namearray[11])", for: .normal)
            
            break
            
        case "Tree" :
            
            
            Imagee.image = imageArray[12]
            Button1.setTitle("\(namearray[12])", for: .normal)
            
            break
            
            
        case "Grass":
            
            Imagee.image = imageArray[13]
            Button2.setTitle("\(namearray[13])", for: .normal)
            
            break
            
            
            
        case "Street" :
            
            Imagee.image = imageArray[14]
            Button3.setTitle("\(namearray[14])", for: .normal)
          
            
            break
            
        case "Ground" :
            
            
            Imagee.image = imageArray[15]
            Button4.setTitle("\(namearray[15])", for: .normal)
            
            break
            
            
        case "Hospital":
            
            Imagee.image = imageArray[16]
            Button1.setTitle("\(namearray[16])", for: .normal)
            
            
            break
            
            
            
        case "School" :
            
            Imagee.image = imageArray[17]
            Button2.setTitle("\(namearray[17])", for: .normal)
            
            
            break
            
        case "Mouse" :
            
            
            Imagee.image = imageArray[18]
            Button3.setTitle("\(namearray[18])", for: .normal)
            
            break
            
            
        case "Parrot":
            
            Imagee.image = imageArray[19]
            Button4.setTitle("\(namearray[19])", for: .normal)
            
            break
            
            
            
        case "Tomato" :
            
            Imagee.image = imageArray[20]
            Button1.setTitle("\(namearray[20])", for: .normal)
            
            
            break
            
            
        default:
          
            break
        }
        
    
    }
    
    func randomAlphabate(){
        
        
        let number1 = Int(arc4random_uniform(UInt32(namearray.count)));
        let number2 = Int(arc4random_uniform(UInt32(namearray.count)));
        let number3 = Int(arc4random_uniform(UInt32(namearray.count)));
        let number4 = Int(arc4random_uniform(UInt32(namearray.count)));
        
        Button1.setTitle("\(namearray[number1])", for: .normal)
        Button2.setTitle("\(namearray[number2])", for: .normal)
        Button3.setTitle("\(namearray[number3])", for: .normal)
        Button4.setTitle("\(namearray[number4])", for: .normal)
        
    }
    
    
    
    
    @IBAction func ButtonOneAction(_ sender: UIButton) {
        if Button1.currentTitle == LevelLabel.text! {
            
             AudioPlyer.play()
            RightAttempt += 1
            RightLabel.text = "Right: \(RightAttempt)"
         
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
            
            
        }
        
        
        else {
         AudioPlyer2.play()
        wrongAttempt += 1
        WrongLabel.text = "Wrong: \(wrongAttempt)"
        
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
            
            
            
        }
        
        
        }
    
    
    @IBAction func ButtonTwoAction(_ sender: UIButton) {
        if Button2.currentTitle == LevelLabel.text! {
            
             AudioPlyer.play()
            RightAttempt += 1
            RightLabel.text = "Right: \(RightAttempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
            
            
            
        }
            
            
        else {
             AudioPlyer2.play()
            wrongAttempt += 1
            WrongLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
        }
        
        
        
    }
    
    
    @IBAction func ButtonThreeAction(_ sender: UIButton) {
        if Button3.currentTitle == LevelLabel.text! {
            
             AudioPlyer.play()
            RightAttempt += 1
            RightLabel.text = "Right: \(RightAttempt)"
           
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
        }
            
            
        else {
             AudioPlyer2.play()
            wrongAttempt += 1
            WrongLabel.text = "Wrong: \(wrongAttempt)"
           
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
        }
        
        
    }
    
    
    @IBAction func ButtonFourAction(_ sender: UIButton) {
        
        if Button4.currentTitle == LevelLabel.text! {
            
             AudioPlyer.play()
            RightAttempt += 1
            RightLabel.text = "Right: \(RightAttempt)"
           
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
            
        }
            
            
        else {
             AudioPlyer2.play()
            wrongAttempt += 1
            WrongLabel.text = "Wrong: \(wrongAttempt)"
         
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            
        }
        
        
    }
    
    @IBAction func Refresh(_ sender: UIButton) {
        
        
        randomAlphabate()
        StoreImageAndName ()
        
        Button1.isEnabled = true
        Button2.isEnabled = true
        Button3.isEnabled = true
        Button4.isEnabled = true
        
        
        
    }
    
    }


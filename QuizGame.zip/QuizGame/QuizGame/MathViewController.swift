//
//  MathViewController.swift
//  QuizGame
//
//  Created by spkamran on 17/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit

class MathViewController: UIViewController {

    
    @IBOutlet var Buttons: [UIButton]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        for myButoons in Buttons {
        
        myButoons.layer.cornerRadius = 18
        
        }
    }
    @IBAction func PlusButtonAction(_ sender: UIButton) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "AdditionStory")
        
        present(pass!, animated: true, completion: nil)
        
        
        
        
        sender.pulsate()
        
        
           }
    
    
    
    @IBAction func SubtractButton(_ sender: UIButton) {
        
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "SubtractStory")
        
        present(pass!, animated: true, completion: nil)
        
        
        
        sender.flash()

    }
    
    
    @IBAction func MultipleButton(_ sender: UIButton) {
       
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "MltiplyStory")
        
        present(pass!, animated: true, completion: nil)
        
        
        sender.shake()

    }
    
    
    @IBAction func DivisionButton(_ sender: UIButton) {
       
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "DivideStory")
        
        present(pass!, animated: true, completion: nil)
        
        
        sender.shake()

    }
    
    
    @IBAction func EquationButton(_ sender: UIButton) {
        let pass = self.storyboard?.instantiateViewController(withIdentifier: "AboutStory")
        
        present(pass!, animated: true, completion: nil)
        
        sender.flash()

    }
    
    
    
    @IBAction func buttonActionHome(_ sender: Any) {
        
        
        let passHome = self.storyboard?.instantiateViewController(withIdentifier: "mainStory")
        
        present(passHome!, animated: true, completion: nil)
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

//
//  MultiplyViewController.swift
//  QuizGame
//
//  Created by spkamran on 20/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class MultiplyViewController: UIViewController {

    
    @IBOutlet weak var ScoreLabel: UILabel!
    
    
    @IBOutlet weak var LevelLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    
    @IBOutlet weak var valueLabel2: UILabel!
    
    @IBOutlet weak var valueLabel1: UILabel!
    
    @IBOutlet var CollectionsOfButtons: [UIButton]!
    
    @IBOutlet weak var AttemptLabel: UILabel!
    
    @IBOutlet weak var WrongAttemptLabel: UILabel!
    
    
    
    //outlets ======== ======== ========>>>> //outlets
    
    //            |||      //
    //            |||      //
    //            |||      //
    
    
    
    //Variables ======== ======== ========>>>> //Variables
    
    var score:Int = Int();          // score variable
    
    var Attempt:Int = Int();        // attempt variable in Right label
    
    var wrongAttempt:Int = Int();   // attempt variable in Right label
    
    var CountLevel:Int = Int();     // countlabel variable
    
    var LevelLbl:Int = Int();       // level variable level
    
    var Timelbl:Int = Int();        // time variable lebel
    
    var StoreCountLabelValue:String = String(); // countlabel storage value variable
    
    var timer = Timer() /// Timer variable
    
    var timee:Int = 60; // time variable
    
    var value1:Int = Int(); // first value of label foe sum
    
    var value2:Int = Int(); // second value of label for sum
    
    var answer:Int = Int(); //  variable store sum of labels value
    
    var AudioPlyer:AVAudioPlayer = AVAudioPlayer();
    
    var AudioPlyer2:AVAudioPlayer = AVAudioPlayer();
    
    //Variables ======== ======== ========>>>> //Variables
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimerStoreIntimeLabel() //TimerStoreIntimeLabel function
        // ButtonsOperations ()
        playAudio()
        playAudio2()
        
        RandomOperation()
    }
    
    
    
    
    
    
    func playAudio(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "yay", ofType: ".wav")
            try
                AudioPlyer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    
    func playAudio2(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "ooooh", ofType: ".wav")
            try
                AudioPlyer2 = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    
    

    
    
    public func TimerStoreIntimeLabel(){ ///   =============>>>>>>TimerStoreIntimeLabel start
        
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(AlphabateQuizViewController.Action), userInfo: nil, repeats: true)
        
        
    }// ///  =======>>>>>> TimerStoreIntimeLabel start
    
    
    @objc func Action(){// ==============>>>>>>>> action of time
        
        timee -= 1
        
        timeLabel.text! = String("Time: 00:\(timee)")
        
        if timee == 0 {// =======>>>>>>>if
            
            timer.invalidate()
            
            let ttext = AttemptLabel.text!
            
            let ttext2 = WrongAttemptLabel.text!
            
            
            
            let alrt = UIAlertController(title: "Warning", message: "Time Out You Loss", preferredStyle: .alert)
            
            alrt.addAction(UIAlertAction(title: "\(ttext2)", style: .default))
            
            alrt.addAction(UIAlertAction(title:"\(ttext)", style: .default))
            
            present(alrt, animated: true, completion: nil)
            
            valueLabel1.text = "00"
            valueLabel2.text = "00"
            
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
        }//====>>>>>>>if
        
        
        
        
        
        
        
    }//  ==============>>>>>>>> action of time
    
    
    
    func RandomOperation(){  // ==============>>>>>>>> Random Operation function start
        
        
        
        
        
        
        
        let number1 = String(arc4random_uniform(31));
        let number2 = String(arc4random_uniform(31));
        let number3 = String(arc4random_uniform(31));
        let number0 = String(arc4random_uniform(31));
        
        let number4 = String(arc4random_uniform(31));
        var number5 = String(arc4random_uniform(31));
        
        
        
        valueLabel1.text = "\(number5)"
        valueLabel2.text = "\(number4)"
        
        value1 = Int(valueLabel1.text!)!
        value2 =   Int(valueLabel2.text!)!
        
        answer = (value1*value2)
        
        
        
        
        
        
        number5 = valueLabel2.text!
       
        if number5 == "1" || number5 == "3" || number5 == "5" || number5 == "2" || number5 == "4" || number5 == "6"
            || number5 == "25" || number5 == "28" {
            
            
            CollectionsOfButtons[0].setTitle("\(answer)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number3)", for: .normal)
            
            
            
            
        }
        
        
        
        if number5 == "7" || number5 == "9" || number5 == "11" || number5 == "8" || number5 == "10" || number5 == "12"  || number5 == "27" {
            
            
            
            
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(answer)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
            
            
        }
        
        
        if number5 == "13" || number5 == "15" || number5 == "17" || number5 == "14" || number5 == "16" || number5 == "18" || number5 == "29" {
            
       
            
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(answer)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
            
            
        }
        
        
        if number5 == "19" || number5 == "21" || number5 == "23" || number5 == "20" || number5 == "22" || number5 == "24" || number5 == "30" || number5 == "26" {
            
            
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(answer)", for: .normal)
            
            
        }
        
        
        
        
    }   ///===========>>>>> ButtonsOperation function
    
    
    
    public func ConditionToUpdateLevels(){ // =================>>>>>>>>>>ConditionToUpdateLevels start
        StoreCountLabelValue = AttemptLabel.text!// assigned value of Countlbel text in variable storagecountlabel
        
        
        
        if (StoreCountLabelValue == "Right: 10" || StoreCountLabelValue == "Right: 20" || StoreCountLabelValue == "Right: 30" || StoreCountLabelValue == "Right: 40" || StoreCountLabelValue == "Right: 50" )
        {// =============>>>>>>>> if start
            
            LevelLbl += 1
            LevelLabel.text = "Level: \(LevelLbl)" // updating levels and store in label
            
            timee += 10
            timeLabel.text = "Time: 00:\(timee)" // updatimg time and store in label
        
        }// iff end
        
        
    }  //=====================>>>>>>>>>>>>>CondtionToUpdateLevels function end
    
    
 
    

    @IBAction func Button0(_ sender: UIButton) {
       
        ConditionToUpdateLevels()
        
        let getButtonText = CollectionsOfButtons[0].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
             AudioPlyer.play()
            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            WrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()
            wrongAttempt += 1
            WrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            WrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
        }
        

        
    }

    @IBAction func Button1(_ sender: UIButton) {
        
        ConditionToUpdateLevels()
        
        
        
        
        
        let getButtonText = CollectionsOfButtons[1].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
             AudioPlyer.play()
          Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            WrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()
            wrongAttempt += 1
            WrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            WrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        
        
        
        
    }


    @IBAction func Button3(_ sender: UIButton) {
        
        ConditionToUpdateLevels()
        
        
        
        
        let getButtonText = CollectionsOfButtons[2].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
             AudioPlyer.play()
            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            WrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()
            wrongAttempt += 1
            WrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            WrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        
        
    }




    @IBAction func Button4(_ sender: UIButton) {
        
        ConditionToUpdateLevels()
        
        
        
        let getButtonText = CollectionsOfButtons[3].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
             AudioPlyer.play()
            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            WrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()
            wrongAttempt += 1
            WrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            WrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        

        
        
        
    }


    @IBAction func RefreshButton(_ sender: UIButton) {
        
        CollectionsOfButtons[0].isEnabled = true
        CollectionsOfButtons[1].isEnabled = true
        CollectionsOfButtons[2].isEnabled = true
        CollectionsOfButtons[3].isEnabled = true
        
        
        
        RandomOperation()
        UpdateLevel2()
        UpdateLevel3()
        
        
        
    }

    @IBAction func home(_ sender: UIButton) {
        
        
        
        let passhome = storyboard?.instantiateViewController(withIdentifier: "MathStory")
        present(passhome!, animated: true, completion: nil)
        
        
        
    }

    
    
    func UpdateLevel2(){  // ==============>>>>>>>> Random Operation function start
        
        if LevelLabel.text == "Level: 1" {
            
            
            
            
            
            let number1 = String(arc4random_uniform(71));
            let number2 = String(arc4random_uniform(71));
            let number3 = String(arc4random_uniform(71));
            let number0 = String(arc4random_uniform(71));
            
            let number4 = String(arc4random_uniform(71));
            var number5 = String(arc4random_uniform(71));
            
            
            
            valueLabel1.text = "\(number4)"
            valueLabel2.text = "\(number5)"
            
            value1 = Int(valueLabel1.text!)!
            value2 =   Int(valueLabel2.text!)!
            
            answer = (value1+value2)
            
            
            
            
            
            number5 = valueLabel2.text!
            
            if number5 == "41" || number5 == "43" || number5 == "45" || number5 == "52" || number5 == "54" || number5 == "56"
                || number5 == "61" || number5 == "63" || number5 == "1" || number5 == "3" || number5 == "5" || number5 == "2" || number5 == "4" || number5 == "6"
                || number5 == "25" || number5 == "28" || number5 == "31" || number5 == "33" {
                
                CollectionsOfButtons[0].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number3)", for: .normal)
                
                
            }
            
            
            
            if number5 == "47" || number5 == "49" || number5 == "51" || number5 == "58" || number5 == "60" || number5 == "62"  || number5 == "57" || number5 == "7" || number5 == "9" || number5 == "11" || number5 == "8" || number5 == "10" || number5 == "12"  || number5 == "27" || number5 == "34" || number5 == "36" {
                
                
                
                
                
                CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
                
                
                
            }
            
            
            if number5 == "70" || number5 == "42" || number5 == "46" || number5 == "48" || number5 == "50" || number5 == "59" || number5 == "29" || number5 == "13" || number5 == "15" || number5 == "17" || number5 == "14" || number5 == "16" || number5 == "18" || number5 == "38" {
                
                
                
                
                CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
                
                
                
            }
            
            if number5 == "0" || number5 == "19" || number5 == "21" || number5 == "23" || number5 == "20" || number5 == "22" || number5 == "24" || number5 == "30" || number5 == "26" || number5 == "0" || number5 == "19" || number5 == "21" || number5 == "23" || number5 == "20" || number5 == "22" || number5 == "24" || number5 == "30" || number5 == "39" || number5 == "55" {
                
                
                
                CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(answer)", for: .normal)
                
                
                
            }
            
        }
        
        
    }   ///===========>>>>> ButtonsOperation function
    
    func UpdateLevel3(){  // ==============>>>>>>>> Random Operation function start
        
        if LevelLabel.text == "Level: 2" {
            
            
            
            
            
            let number1 = String(arc4random_uniform(99));
            let number2 = String(arc4random_uniform(99));
            let number3 = String(arc4random_uniform(99));
            let number0 = String(arc4random_uniform(99));
            
            let number4 = String(arc4random_uniform(99));
            var number5 = String(arc4random_uniform(99));
            
            
            
            valueLabel1.text = "\(number4)"
            valueLabel2.text = "\(number5)"
            
            value1 = Int(valueLabel1.text!)!
            value2 =   Int(valueLabel2.text!)!
            
            answer = (value1+value2)
            
            
            
            
            
            number5 = valueLabel2.text!
            
            if number5 == "41" || number5 == "43" || number5 == "45" || number5 == "52" || number5 == "54" || number5 == "56"
                || number5 == "61" || number5 == "63" || number5 == "1" || number5 == "3" || number5 == "5" || number5 == "2" || number5 == "4" || number5 == "6"
                || number5 == "25" || number5 == "28" || number5 == "31" || number5 == "33" || number5 == "71" || number5 == "81" || number5 == "91" || number5 == "99" || number5 == "72" || number5 == "82"
                || number5 == "92" || number5 == "89" || number5 == "73" || number5 == "83" || number5 == "93" || number5 == "79" {
                
                CollectionsOfButtons[0].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number3)", for: .normal)
                
                
            }
            
            
            
            if number5 == "47" || number5 == "49" || number5 == "51" || number5 == "58" || number5 == "60" || number5 == "62"  || number5 == "57" || number5 == "7" || number5 == "9" || number5 == "11" || number5 == "8" || number5 == "10" || number5 == "12"  || number5 == "27"  || number5 == "34" || number5 == "36" || number5 == "74" || number5 == "84" || number5 == "94" || number5 == "75" || number5 == "85" || number5 == "95"
            {
                
                
                
                
                
                CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
                
                
                
            }
            
            
            if number5 == "70" || number5 == "42" || number5 == "46" || number5 == "48" || number5 == "50" || number5 == "59" || number5 == "29" || number5 == "13" || number5 == "15" || number5 == "17" || number5 == "14" || number5 == "16" || number5 == "18"  || number5 == "38" || number5 == "76" || number5 == "86"  || number5 == "96" || number5 == "78"
                
                
            {
                
                
                
                
               CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(answer)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
                
                
                
            }
            
            if number5 == "0" || number5 == "19" || number5 == "21" || number5 == "23" || number5 == "20" || number5 == "22" || number5 == "24" || number5 == "30" || number5 == "26" || number5 == "0" || number5 == "19" || number5 == "21" || number5 == "23" || number5 == "20" || number5 == "22" || number5 == "24" || number5 == "30" || number5 == "39" ||  number5 == "77"  || number5 == "87" || number5 == "97" || number5 == "87" || number5 == "98"  {
                
                
                
                CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
                
                CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
                
                CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
                
                CollectionsOfButtons[3].setTitle("\(answer)", for: .normal)
                
                
                
            }
            
        }
        
        
    }   ///===========>>>>> Level upgrade function
    
    

    
    
    
    
    
    
    
}

//
//  DividViewController.swift
//  QuizGame
//
//  Created by spkamran on 20/01/2019.
//  Copyright © 2019 spkamran. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class DividViewController: UIViewController {

    
    @IBOutlet weak var ScoreLabel: UILabel!
    
    
    @IBOutlet weak var LevelLabel: UILabel!
    
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    @IBOutlet weak var value1Label: UILabel!
    
    @IBOutlet weak var value2Label: UILabel!
    
    
    @IBOutlet var CollectionsOfButtons: [UIButton]!
    
    
    @IBOutlet weak var AttemptLabel: UILabel!
    
    @IBOutlet weak var wrongAttemptLabel: UILabel!
    
    //outlets ======== ======== ========>>>> //outlets
    
    //            |||      //
    //            |||      //
    //            |||      //
    
    
    
    //Variables ======== ======== ========>>>> //Variables
    
    var score:Int = Int();          // score variable
    
    var Attempt:Int = Int();        // attempt variable in Right label
    
    var wrongAttempt:Int = Int();   // attempt variable in Right label
    
    var CountLevel:Int = Int();     // countlabel variable
    
    var LevelLbl:Int = Int();       // level variable level
    
    var Timelbl:Int = Int();        // time variable lebel
    
    var StoreCountLabelValue:String = String(); // countlabel storage value variable
    
    var timer = Timer() /// Timer variable
    
    var timee:Int = 90; // time variable
    
    var value1:Float = Float(); // first value of label foe sum
    
    var value2:Float = Float(); // second value of label for sum
    
    var answer:Float = Float(); //  variable store sum of labels value
    
    var AudioPlyer:AVAudioPlayer = AVAudioPlayer();
    
    var AudioPlyer2:AVAudioPlayer = AVAudioPlayer();
    
    
    //Variables ======== ======== ========>>>> //Variables
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TimerStoreIntimeLabel() //TimerStoreIntimeLabel function
        // ButtonsOperations ()
        
        RandomOperation()
        playAudio()
        playAudio2()
        
    }
    
    
    
    
    
    
    func playAudio(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "yay", ofType: ".wav")
            try
                AudioPlyer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    
    func playAudio2(){
        
        do{
            
            let audio = Bundle.main.path(forResource: "ooooh", ofType: ".wav")
            try
                AudioPlyer2 = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audio!) as URL)
        }
        catch{
            
            print("error")
            
        }
        
    }
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    public func TimerStoreIntimeLabel(){ ///   =============>>>>>>TimerStoreIntimeLabel start
        
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(AlphabateQuizViewController.Action), userInfo: nil, repeats: true)
        
        
    }// ///  =======>>>>>> TimerStoreIntimeLabel start
    
    
    @objc func Action(){// ==============>>>>>>>> action of time
        
        timee -= 1
        
        TimeLabel.text! = String("Time: 00:\(timee)")
        
        if timee == 0 {// =======>>>>>>>if
            
            timer.invalidate()
            
            let ttext = AttemptLabel.text!
            
            let ttext2 = wrongAttemptLabel.text!
            
            
            
            let alrt = UIAlertController(title: "Warning", message: "Time Out You Loss", preferredStyle: .alert)
            
            alrt.addAction(UIAlertAction(title: "\(ttext2)", style: .default))
            
            alrt.addAction(UIAlertAction(title:"\(ttext)", style: .default))
            
            present(alrt, animated: true, completion: nil)
            
            value2Label.text = "00"
            value1Label.text = "00"
            
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
        }//====>>>>>>>if
        
        
        
        
        
        
        
    }//  ==============>>>>>>>> action of time
    
    
    
    func RandomOperation(){  // ==============>>>>>>>> Random Operation function start
        
        
        
        
        
        
        
        let number1 = String(arc4random_uniform(31));
       
        let number2 = String(arc4random_uniform(31));
        
        let number3 = String(arc4random_uniform(31));
        
        let number0 = String(arc4random_uniform(31));
        
        let number4 = String(arc4random_uniform(115));
        
        var number5 = String(arc4random_uniform(21));
        
        
        value1Label.text! = "\(number5)"
        value2Label.text! = "\(number4)"
        
        value1 = Float(value1Label.text!)!
        value2 =   Float(value2Label.text!)!
        
        answer = (value1/value2);
        
        
        CollectionsOfButtons[0].setTitle("\(number0)", for: .normal)
        
        CollectionsOfButtons[1].setTitle("\(number1)", for: .normal)
        
        CollectionsOfButtons[2].setTitle("\(number2)", for: .normal)
        
        CollectionsOfButtons[3].setTitle("\(number3)", for: .normal)
        
       
        
        
        number5 = value2Label.text!
        
        if number5 == "0" || number5 == "1" || number5 == "3" || number5 == "5"  || number5 == "7" || number5 == "9" {
           
            
            CollectionsOfButtons[0].setTitle("\(answer)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number3)", for: .normal)
            
            
    
        }
        
        
        
        if number5 == "11" || number5 == "13" || number5 == "15" || number5 == "17" || number5 == "19" {
            
            


           
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
           CollectionsOfButtons[1].setTitle("\(answer)", for: .normal)
            CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
            
            
        }
        
        
        if number5 == "2" || number5 == "4" || number5 == "6" || number5 == "8" || number5 == "10" {
            
            
            
            
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(answer)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(number0)", for: .normal)
            
                    }
       
        if number5 == "12" || number5 == "14" || number5 == "16" || number5 == "18" || number5 == "20" {
            
            
            
            CollectionsOfButtons[0].setTitle("\(number1)", for: .normal)
            
            CollectionsOfButtons[1].setTitle("\(number2)", for: .normal)
            
            CollectionsOfButtons[2].setTitle("\(number3)", for: .normal)
            
            CollectionsOfButtons[3].setTitle("\(answer)", for: .normal)
            
            
        }
        
        
        
        
    }   ///===========>>>>> ButtonsOperation function
    
    
    
    public func ConditionToUpdateLevels(){ // =================>>>>>>>>>>ConditionToUpdateLevels start
        
        StoreCountLabelValue = AttemptLabel.text!// assigned value of Countlbel text in variable storagecountlabel
        
        
        if (StoreCountLabelValue == "10" || StoreCountLabelValue == "20" || StoreCountLabelValue == "30" || StoreCountLabelValue == "40" || StoreCountLabelValue == "50")
        {// =============>>>>>>>> if start
            
            LevelLbl += 1
            LevelLabel.text = "Level: \(LevelLbl)" // updating levels and store in label
            
            timee += 10
            TimeLabel.text = "Time: 00:\(timee)" // updatimg time and store in label
            
        }// ==========>>>>> if end
        
        
        
    }  //=====================>>>>>>>>>>>>>CondtionToUpdateLevels function end
 
    
    

    
    
    @IBAction func Button0(_ sender: UIButton) {
        
        
        
        ConditionToUpdateLevels()
        
        let getButtonText = CollectionsOfButtons[0].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
            AudioPlyer.play()

            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            wrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()

            wrongAttempt += 1
            wrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            wrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
        }
        
        
    }
    
    
    @IBAction func Button1(_ sender: UIButton) {
        
        
        
        
        ConditionToUpdateLevels()
        
        let getButtonText = CollectionsOfButtons[1].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
            AudioPlyer.play()

            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            wrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()

            wrongAttempt += 1
            wrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            wrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
        }
        
        
        
        
        
    }
    
    
    @IBAction func Button2(_ sender: UIButton) {
        
        
        
        
        ConditionToUpdateLevels()
        
        let getButtonText = CollectionsOfButtons[2].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
            AudioPlyer.play()

            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            wrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()

            wrongAttempt += 1
            wrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            wrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
        }
        
        
        
    }
    
    
    @IBAction func Button3(_ sender: UIButton) {
     
        
        
        ConditionToUpdateLevels()
        
        let getButtonText = CollectionsOfButtons[3].currentTitle!
        
        let getans:String = String(answer);
        
        
        if getButtonText == getans {
            AudioPlyer.play()

            Attempt += 1
            AttemptLabel.text = "Right: \(Attempt)"
            
            score += 10
            ScoreLabel.text = "Score: \(score)"
            
            AttemptLabel.backgroundColor = UIColor.green
            wrongAttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
            
        }
        else if getButtonText != getans {
            AudioPlyer2.play()

            wrongAttempt += 1
            wrongAttemptLabel.text = "Wrong: \(wrongAttempt)"
            
            score -= 10
            ScoreLabel.text = "Score: \(score)"
            
            wrongAttemptLabel.backgroundColor = UIColor.red
            AttemptLabel.backgroundColor = UIColor.cyan
            
            CollectionsOfButtons[0].isEnabled = false
            CollectionsOfButtons[1].isEnabled = false
            CollectionsOfButtons[2].isEnabled = false
            CollectionsOfButtons[3].isEnabled = false
            
            
        }
        
        
    }
    
    
    @IBAction func RefreshButton(_ sender: UIButton) {
        
       
        CollectionsOfButtons[0].isEnabled = true
        CollectionsOfButtons[1].isEnabled = true
        CollectionsOfButtons[2].isEnabled = true
        CollectionsOfButtons[3].isEnabled = true
        
        
        
        RandomOperation()
        
    }
    
    
    
    @IBAction func HomeButton(_ sender: UIButton) {
        
        
        let refresh = self.storyboard?.instantiateViewController(withIdentifier: "MathStory")
        
        present(refresh!, animated: true, completion: nil)
        
        
        
    }
    
    
    
    
    
    
    
}
